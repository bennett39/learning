==============
 Process lock
==============

-------
Classes
-------

.. autoclass:: fasteners.process_lock.InterProcessLock
   :members:

.. autoclass:: fasteners.process_lock._InterProcessLock
   :members:

----------
Decorators
----------

.. autofunction:: fasteners.process_lock.interprocess_locked
